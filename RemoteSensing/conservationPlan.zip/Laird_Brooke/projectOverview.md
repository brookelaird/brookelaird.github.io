# Public Access Trails:

### Introduction:
 Middlebury must continue to provide inclusive recreational opportunities that allow all residents and visitors to engage with the landscape in **sustainable** and **fulfilling ways**.

### Problems in Current Trail Access:
Despite an extensive public trail system in Middlebury
and the surrounding area, there are still areas in the  community that have limited access to these recreational paths. In addition, some trailheads may be inaccessible for residents to use without using a vehicle.

### Goals for the future of public access trails:
1. Trails more equally serve regions of the Middlebury community based on walkability to trail heads
2. Any future trail development is carried out in a way that minimizes destruction to natural communities and habitats areas outlined in this report and beyond.
3. Trails are actively supported and maintained to provide recreation opportunity for a variety of audiences and activities.

### Analyzing Trail Access:
The results of our GIS analysis suggest that a majority of Middlebury residents live within a 15 minute walking distance to a trail access point used in this report.

Visit the online conservation atlas to see specific estimated travel times for different areas of Middlebury.


### Known Limitations and Further Work:
This analysis provides an estimation for walking times to trail access points based on an average walking speed. For many Middlebury residents, walking time can be significantly lengthened due to weather conditions or ability.

This analysis determines access to trails at the intersection of roads and trails. It is likely that not all trail access points were accounted for, especially access points that are not widely used by the public.

We can continue to strengthen our analysis of trail accessibility by incorporating other factors into our analysis that can limit trail usability, such as type of recreation that is permitted, trail difficulty, and the distance of public transportation stops to trail access points.

For more information, please visit the methods documentation and background report.
