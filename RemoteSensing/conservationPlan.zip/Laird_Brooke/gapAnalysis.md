# Gap Analysis
By expanding on our present conditions layer, we can next visualize the unequal distribution of access to trail and public green space in Middlebury.

## Introduction:
After determining the proximity to an access point from different areas of Middlebury, we can next determine the number of residential buildings in the different distance catchments. In doing so, we can find patterns in the spatial distribution of housing and trail access in Middlebury. This will help us determine where **"access deserts,"**
parts of town with no walkable trail access, are located. This can help as a guide if there is future conversation about  where any rail development should be focused, or where class 4 roads and gravel roads should be maintained as they can serve similar roles to trails.


## Data Prep:

The only new steps beyond the processing for the present conditions layer is processing E911 points from VCGI into residential points, and then into a raster layer. These steps can be found in the [trails GEE script](https://code.earthengine.google.com/4b6c7af8cec21c2b4d6319b485c10a44).

![residences](images/residences.png)
The e911 residential points raster overlayed on the cost distance analysis output. Residential types are color coded based on type (see table below.)

##  Gap Analysis:
First, the output from the cost distance analysis was used to create distance time-sheds/ catchment areas, that represent the time threshold it takes to reach an access point from that area.

The following classification was used for the reclass:

| Pixel Threshold | Predicted Walk Time | Reclass Value
| ----------- | ------------- |---------- |
| less than 300   | 5 minutes or less       | 1|
| between 300 and 600           | 10 minutes       | 2|
| between 600 and 900             | 15 minutes      | 3|
| between 900 and 1200             | 20 minutes      | 4|
| greater than 1200            | not within a 20 minute walk      |5|

This step was carried out using the following python code:
```Python
wbt.reclass(
    i = distanceOutput,
    output = "01_timesheds.tif",
    reclass_vals = "1.0;min;300.0;2.0;300.0;600.0;3.0;600.0;900.0;4.0;900.0;1200.0;5.0;1200.0;max",
    assign_mode=False
)
```

The resulting timesheds for our study region can be seen below, however, as identified in our present conditions layer, the study region was small enough that every residence in the area was within a 5 minute or 10 minute walk.

![timesheds](images/timesheds.png)

The red catchment is within a 5 minute walk, and the yellow is a 10 minute walk. The trail network is visible in green, and the origin point used for the analysis is represented with a black star.

### Using Zonal Statistics to Find Residences in Each Timeshed:

Next, we used zonal statistics to determine the number of residences in each walking distance timeshed.

This first required a reclassification of the e911 residences raster (currently seperated into different housing types) into a binary of residence/no residence.

```Python
#turn e911 raster into binary
wbt.reclass(
    i = residences,
    output = "02_e911binary.tif",
    reclass_vals = "0;0;1;1;1;2;1;3;1;4;1;5",
    assign_mode=True
)
```

Next, we can get statistics of the e911 binary layer using the timesheds as the input feature, gathering statistics on the total number of e911 residences in each timeshed.

```Python
#number of total residences in each timeshed
wbt.zonal_statistics(
    i = "02_e911binary.tif",
    features = "01_timesheds.tif" ,
    output= None,
    stat= "total",
    out_table = "03_allresidences_zonalstat.xls",
)
```

The following table was produced as a result of the initial zonal statistic analysis of all residential buildings in the study region:

| Timeshed   | Number of Residences | Percent of Total Residences |
| ----------- | ------------- | ----------------------------|
| 5 minute walk  | 3347             | 84%
| 10 minute walk    | 639             |16%


## Distance to Origin Based on Residential Type:
The first zonal statistics step (above) is repeated for each of the 5 housing categories.
First a binary raster is created with 1 = residences of that housing type, and all other housing types or no residence classed as 0.

| Residential Type   | Classification on Raster |
| ----------- | ------------- |
| Not Residential  | 0             |
| Commercial with Residence    | 1             |
| Condominium    | 2             |
| Mobile Home    | 3            |
| Multi Family Dwelling    | 4             |
| Single Family Dwelling | 5|

![graph1](images/graph1.png)

The study region is comprised mostly of single family homes, with some condominiums and multi-family homes also present. Unfortunately, this study region did not have any mobile homes or commercial with residential buildings present, but these residential classes can be seen in the larger analysis of the entire town.

## Visualizing our Results:

![graph2](images/graph2.png)

All of the housing types represented in the study region were within a 10 minute walk of the origin point. **100% of condominiums are within  a 5 minute walk, more than 70% of multi-family homes, and more than 80% of single family homes.**
