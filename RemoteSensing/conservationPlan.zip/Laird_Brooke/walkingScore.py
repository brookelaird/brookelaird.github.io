# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   name:     walkingScore.py
#  purpose:  By modeling the surface as a cost grid, we can determine what areas
# have the greatest access to a trail head based on walking time on non highway roads
#
#  author:  Brooke Laird, co author Jeff Howarth
#  update:   11/16/2021
#  license:  Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# import tools from WBT module

from WBT.whitebox_tools import WhiteboxTools

# declare a name for the tools

wbt = WhiteboxTools()

# Set the Whitebox working directory
# You will need to change this to your local path name

wbt.work_dir = "/Users/brookelaird/Desktop/GEOG0310/wbt_pySpace-master/costData"

#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Test datasets:
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

rdstest = "Roads_test2.tif"

trails_test = "trailsRaster.tif"

origin_pt = "chip_trailhead_raster.tif"

# in this analysis there is 1 origin point used, but in the full
#analysis of trail in Middlebury it will be an origin layer with all access points.

#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Create Raster with Road Classes (Float32):
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# create blank raster as float (to force rasters to store decimal values)
wbt.new_raster_from_base(
    base = rdstest,
    output = "00_base.tif",
    value = "1",
    data_type = "float"
)
# convert rds to float

wbt.multiply(
    input1 = "00_base.tif",
    input2 = rdstest,
    output = "00_rds_float.tif"
)

#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Reclass Road into Friction Values
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#reclass road into friction values. 100 if surface is unwalkable such as no roads or highway, .28 if walkable
wbt.reclass(
    i = "00_rds_float.tif",
    output = "03_rds_float_reclass.tif",
    reclass_vals = "0.56;0.0;0.56;1.0;0.28;3.0;0.28;4.0;0.28;9.0;0.56;40.0",
    assign_mode=True
)

#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Cost Distance Analysis
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

wbt.cost_distance(
    source = "chip_trailhead_raster.tif", #what is your origin point raster?
    cost = "03_rds_float_reclass.tif",
    out_accum = "000_output4.tif", #total cost of moving from origin to anywhere else
    out_backlink = "zz_backlink.tif" #how did you move
    #callback=default_callback
)

#For analysis of the output raster, visit the markdown documentation file
