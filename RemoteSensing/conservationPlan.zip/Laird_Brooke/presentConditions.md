# Present Conditions

### Introduction

Public access trails are an essential element of Middlebury's community, providing a means for residents and visitors to explore the natural environment around them. Despite the extensive network of trails that exists in Middlebury and the surrounding community, it is important to acknowledge that trails do not equally serve all portions of the town, especially when considering where people could comfortably walk to a trail access point.

First, in a documentation of present conditions, we visualized where there are **public access** points to trails. Public access, in this analysis, is defined as locations where walkable roads intersect with trails. These public access points are essential not only as points of trail access, but also because trails can lead to more open green space that allows for a variety of other outdoor activity.

After documenting the present conditions of public access trails in Middlebury, we can determine where there are gaps in the distribution of this amenity. In order to analyze gaps in access to public recreation trails in Middlebury, we used a **cost distance analysis** to see the difficulty of reaching an access point from different parts of the community, modeled as a cost raster. In an ideal scenario, access to protected lands should be equitable for all residents of Middlebury, regardless of location or housing type. A **cost distance analysis** is a general GIS function that determines optimal routes of travel through space, and the "cost"--whether it be a distance or time--that it takes to get from one point or pixel to another. Cost distance analyses can be done using vector points or through a raster as a cost grid. In this analysis, we used a raster which provides results at the pixel level, and can be run using [Whitebox Tools](https://www.whiteboxgeo.com) for Python, allowing for easy replication of the code in different study areas.

### Data Layers
This analysis used a test region of Middlebury, and the origin point was dropped at the Monroe Street entrance to Battell Woods.
![test area](images/studyregion.png)

Other layers include the [roads dataset](https://geodata.vermont.gov/datasets/VTrans::vt-road-centerline/explore), and trails layer, and trail head points, all of which can be found in data preprocessing section of this [google earth engine script](https://code.earthengine.google.com/645fdfa7780be86381eadaf1c0cc4ee8) (see lines 31-116).

*Note: If downloading large files from Google Earth Engine becomes difficult, a byte size file will take up less space and will download faster. Data should be converted to a Float32 size file for best results, and this can be done in QGIS with the Gdal raster conversion "translate" tool.*

## Distance Analysis based on Walkability

This analysis section aims to answer the question: **how far/long would someone have to walk to access the nearest trailhead?**
The distance analysis, and the respective code, can be broken down into 3 sections--data prep, reclassification into cost grid, and cost analysis.  

### Data Prep:

Data pre-processing steps occurred in the trails [google earth engine script](https://code.earthengine.google.com/19899d861d68ba80d7a964b158445c99).

To create an **origin points layer,** the layer that represents points of trail access, I hand-placed 33 points in QGIS into a point layer, which can be found in the trails [google earth engine script](https://code.earthengine.google.com/19899d861d68ba80d7a964b158445c99) as a shapefile or a raster.

I also ran an analysis on the access points to identify certain points of trail
access that lead into habitat blocks. This allows us to identify specific trail access
areas where people are recreating in a larger, habitat block area.

### Reclassification into Cost grid:

Next, we have the reclassification of the roads raster into a **friction raster.** A **friction raster**, or cost raster, is a raster where pixels are reclassified based on how difficult it is to move through them--how much friction that pixel has. In this analysis, a pixel that is classified as not containing a road, or containing a highway is classified to a value of **0.56**, because people will walk very slowly on this type of surface when moving through the landscape to the trail head. Other roads, such as class 3 or private roads receive a reclass value of **0.28** which represents little friction. Classes and friction values are based off of this [friction calculator](https://docs.google.com/spreadsheets/d/1W5HSLznPawzpYnyAIHZkpFdyk5GlUd77brhpmRTAvm4/edit#gid=0).

*It is important to note that reclass values derived from the friction calculator rely on information about the pixel size. Make sure the pixel size is know before determining your values for the friction layer.*

| Road Type   | Initial Class | New Class |
| ----------- | ------------- |---------- |
| No Road     | 0             | 0.56       |
| Highway     | 1             | 0.56       |
| Class 3     | 3             | 0.28      |
| Class 4     | 4             | 0.28      |
| Private     | 9             | 0.28      |


The code for the reclass is as follows:

```Python
#reclass road into friction values. 100 if surface is unwalkable such as no roads or highway, .28 if walkable
wbt.reclass(
    i = "00_rds_float.tif",
    output = "03_rds_float_reclass.tif",
    reclass_vals = "0.56;0.0;0.56;1.0;0.28;3.0;0.28;4.0;0.28;9.0",
    assign_mode=True
)
```

### Cost Analysis:

After the reclass, we can perform the cost analysis using the origin point--trailheads--and the cost grid created in the reclass.

The code for the cost analysis is as follows:

```Python
# cost distance analysis:
wbt.cost_distance(
    source = "chip_trailhead_raster.tif",
    cost = "03_rds_float_reclass.tif",
    out_accum = "000_output.tif", #total cost of moving from origin to anywhere else
    out_backlink = "zz_backlink.tif" #how did you move
    #callback=default_callback
)
```

## Output:

 ![output](images/walkability.png)

 The resulting output represents the levels of walkability to this specific access point in Battell Woods. The green point is the origin, and the black lines are the trails in the area.

 The red value of 300 represents 300 total seconds from point, which is 5 minutes. 600 represents a 10 minute walk. A value of 900 represents a 15 minute walk and 1200 is 20 minutes. The blue represents areas that are likely not within a 20 minute walk to the trail access point. Because the study region was small, all of the tile ended up being within a 5 or 10 minute walk to the trail access point.

 | Color   | Pixel Threshold | Predicted Walk Time |
 | ----------- | ------------- |---------- |
 | Red    | less than 300   | 5 minutes or less       |
 | Orange    | between 300 and 600           | 10 minutes       |
 | Yellow    | between 600 and 900             | 15 minutes      |
 | Green     | between 900 and 1200             | 20 minutes      |
 | Blue     | greater than 1200            | not within a 20 minute walk      |


 Due to the small size of my study area, I have also symbolized the output layer to show catchment areas if they were split up into smaller distance thresholds.
  ![output](images/quantile.png)

 | Color   | Pixel Threshold | Predicted Walk Time |
 | ----------- | ------------- |---------- |
 | Red    | less than 178   | About 3 minutes       |
 | Orange    | between 178 and 258           | About 4 minutes       |
 | Yellow    | between 258 and 349            | About 6 minutes     |
 | Green     | between 349 and 584             | About 9 minutes      |
 | Blue     | greater than 584            | Greater than 9 minutes      |


 
