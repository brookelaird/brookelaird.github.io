# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#   name:     gapAnalysis.py
#  purpose:  To determine the percent of Middlebury residences that are
#         located within different distance thresholds to trail access points
#
#  author:  Brooke Laird, co author Jeff Howarth
#  update:   11/30/2021
#  license:  Attribution-ShareAlike 4.0 International (CC BY-SA 4.0)
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# import tools from WBT module

from WBT.whitebox_tools import WhiteboxTools

# declare a name for the tools

wbt = WhiteboxTools()

# Set the Whitebox working directory
# You will need to change this to your local path name

wbt.work_dir = "/Users/brookelaird/Desktop/GEOG0310/wbt_pySpace-master/gapTest"

#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Test datasets:
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

distanceOutput = "000_output4.tif"

residences = "e911_clipped_residences.tif"

#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Reclass Cost Distance Analysis Output into timesheds
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
wbt.reclass(
    i = distanceOutput,
    output = "timesheds.tif",
    reclass_vals = "1.0;min;300.0;2.0;300.0;600.0;3.0;600.0;900.0;4.0;900.0;1200.0;5.0;1200.0;max",
    assign_mode=False
)


#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Total residences within each timeshed
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#turn e911 raster into binary
wbt.reclass(
    i = residences,
    output = "02_e911binary.tif",
    reclass_vals = "0;0;1;1;1;2;1;3;1;4;1;5",
    assign_mode=True
)
#number of total residences in each timeshed
wbt.zonal_statistics(
    i = "02_e911binary.tif",
    features = "timesheds.tif" ,
    output= None,
    stat= "total",
    out_table = "03_allresidences_zonalstat.xls",
)
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Zonal Statistics: commercial with residence within each timeshed
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
wbt.reclass(
    i = residences,
    output = "04_commercialResidences.tif",
    reclass_vals = "0;0;1;1;0;2;0;3;0;4;0;5",
    assign_mode=True
)
#number of commercial with residences in each timeshed
wbt.zonal_statistics(
    i = "04_commercialResidences.tif",
    features = "timesheds.tif" ,
    output= None,
    stat= "total",
    out_table = "04_commercialresidences_zonalstat.xls",
)
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Zonal Statistics: condo in each timeshed
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
wbt.reclass(
    i = residences,
    output = "05_condos.tif",
    reclass_vals = "0;0;0;1;1;2;0;3;0;4;0;5",
    assign_mode=True
)
#number of condos with residences in each timeshed
wbt.zonal_statistics(
    i = "05_condos.tif",
    features = "timesheds.tif" ,
    output= None,
    stat= "total",
    out_table = "05_condos_zonalstat.xls",
)
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Zonal Statistics: mobile homes in each timeshed
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
wbt.reclass(
    i = residences,
    output = "06_mobilehomes.tif",
    reclass_vals = "0;0;0;1;0;2;1;3;0;4;0;5",
    assign_mode=True
)
#number of mobile homes with residences in each timeshed
wbt.zonal_statistics(
    i = "06_mobilehomes.tif",
    features = "timesheds.tif" ,
    output= None,
    stat= "total",
    out_table = "06_mobilehome_zonalstat.xls",
)

#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Zonal Statistics: multi family dwelling in each timeshed
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
wbt.reclass(
    i = residences,
    output = "07_multifam.tif",
    reclass_vals = "0;0;0;1;0;2;0;3;1;4;0;5",
    assign_mode=True
)
#number of commercial with residences in each timeshed
wbt.zonal_statistics(
    i = "07_multifam.tif",
    features = "timesheds.tif" ,
    output= None,
    stat= "total",
    out_table = "07_multifamily_zonalstat.xls",
)
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#  Zonal Statistics: single family home in each timeshed
#  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
wbt.reclass(
    i = residences,
    output = "08_singlefam.tif",
    reclass_vals = "0;0;0;1;0;2;0;3;0;4;1;5",
    assign_mode=True
)
#number of commercial with residences in each timeshed
wbt.zonal_statistics(
    i = "08_singlefam.tif",
    features = "timesheds.tif" ,
    output= None,
    stat= "total",
    out_table = "08_singlefamily_zonalstat.xls",
)


#for analysis of other e911 buildings and their
#distribution in timesheds this zonal statistics step can be repeated
